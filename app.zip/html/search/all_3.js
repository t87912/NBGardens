var searchData=
[
  ['login',['Login',['../class_login_1_1_login.html',1,'Login']]],
  ['login',['login',['../class_mongo_database_1_1_mongo_database.html#a54df0dccd3550bc038fa246ee0f97a15',1,'MongoDatabase.MongoDatabase.login()'],['../class_my_s_q_l_database_1_1_my_s_q_l_database.html#ac9c6bc35283d4bfeacf4394937c625de',1,'MySQLDatabase.MySQLDatabase.login()']]],
  ['logout',['logout',['../classmain_g_u_i_1_1_main_application.html#af3fa9d6210d07607eb8161acd340eed0',1,'mainGUI::MainApplication']]]
];
