var searchData=
[
  ['onentryclick',['onEntryClick',['../classmain_g_u_i_1_1_main_application.html#a8389dd29b6914c6e878435ba3176f2af',1,'mainGUI::MainApplication']]]
];
