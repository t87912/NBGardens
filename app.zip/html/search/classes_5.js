var searchData=
[
  ['productdetails',['ProductDetails',['../class_mongo_queries_1_1_product_details.html',1,'MongoQueries']]]
];
