var searchData=
[
  ['userstories',['UserStories',['../class_mongo_queries_1_1_user_stories.html',1,'MongoQueries']]]
];
