var searchData=
[
  ['getlogindetails',['getLoginDetails',['../class_login_1_1_login.html#a4ccae6933e82c3ff7d7cb257427064e2',1,'Login::Login']]],
  ['getmenuinput',['getMenuInput',['../classmain_t_u_i_1_1_main_logic.html#ab5d87725a59118bc0816a8a1dd21f06f',1,'mainTUI.MainLogic.getMenuInput()'],['../class_mongo_database_1_1_mongo_database.html#ab5d6d51b956790d3804e4c566ae40cfe',1,'MongoDatabase.MongoDatabase.getMenuInput()'],['../class_my_s_q_l_database_1_1_my_s_q_l_database.html#a01cc9f1c3e782ada4c437682ae31c14c',1,'MySQLDatabase.MySQLDatabase.getMenuInput()']]],
  ['getonlinereviews',['getOnlineReviews',['../class_mongo_queries_1_1_online_reviews.html#a6f3d0736bb3e7890a007e2d4823a6d0d',1,'MongoQueries::OnlineReviews']]],
  ['getpassword',['getPassword',['../class_login_1_1_login.html#a61681c3cd7aae627d5a41324ba0f9d76',1,'Login::Login']]],
  ['getproductdetails',['getProductDetails',['../class_mongo_queries_1_1_product_details.html#acfcdac1a1f030b4753d91ff1e763dab2',1,'MongoQueries::ProductDetails']]],
  ['getproductscores',['getProductScores',['../class_mongo_queries_1_1_customer_order_reviews.html#a4a6fc6cd2e4ff0421c0c67ac5e57e167',1,'MongoQueries::CustomerOrderReviews']]],
  ['getusername',['getUsername',['../class_login_1_1_login.html#a21cb771ec1b1d2d7aa17ca541465200b',1,'Login::Login']]]
];
