var searchData=
[
  ['onlinereviews',['OnlineReviews',['../class_mongo_queries_1_1_online_reviews.html',1,'MongoQueries']]]
];
