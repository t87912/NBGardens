var searchData=
[
  ['customerorderreviews',['CustomerOrderReviews',['../class_mongo_queries_1_1_customer_order_reviews.html',1,'MongoQueries']]]
];
