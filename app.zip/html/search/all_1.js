var searchData=
[
  ['customerorderreviews',['CustomerOrderReviews',['../class_mongo_queries_1_1_customer_order_reviews.html',1,'MongoQueries']]],
  ['custommongo',['customMongo',['../classmain_g_u_i_1_1_main_application.html#adfb6937d77ab2cde3eb371057482ab6e',1,'mainGUI::MainApplication']]],
  ['customquery',['customQuery',['../class_mongo_database_1_1_mongo_database.html#af1be85a82838d6e46f181af707892606',1,'MongoDatabase.MongoDatabase.customQuery()'],['../class_my_s_q_l_database_1_1_my_s_q_l_database.html#a746a62e1c7d7b11e7f00bbcbd92ed860',1,'MySQLDatabase.MySQLDatabase.customQuery()']]],
  ['customsql',['customSQL',['../classmain_g_u_i_1_1_main_application.html#a47ac9da75d8ab9ecd89b3e7590ccf754',1,'mainGUI::MainApplication']]]
];
