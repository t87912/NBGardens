var searchData=
[
  ['run',['run',['../class_mongo_database_1_1_mongo_database.html#afdd3078ad8bb851bab945b1b477f1529',1,'MongoDatabase::MongoDatabase']]],
  ['runprogram',['runProgram',['../classmain_t_u_i_1_1_main_logic.html#a174991d65104326c736a0d8e3c3e8edd',1,'mainTUI::MainLogic']]]
];
