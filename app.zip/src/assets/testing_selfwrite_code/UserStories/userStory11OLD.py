# -*- coding: utf-8 -*-
"""
Created on Tue Sep  6 21:24:58 2016

@author: user
"""

def userStory11(MongoQueries, GUI):
        """ useCase11 """
        #!!!!! very similar to 7 but with dates, needs SQL !!!!#
        print("TBC: need some SQL")