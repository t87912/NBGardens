# -*- coding: utf-8 -*-
"""
Created on Tue Sep  6 21:24:58 2016

@author: user
"""

def userStory8(MongoQueries, GUI, gender):
        """ useCase1: Accepts parameter 'period' which is a period, 1-4 """
        #if (not GUI):
          #  custID = int(input("What gender would you like to search for customer scores by? /n Select from M or F"))
        #if (GUI):
            #!!!!! need an SQL statement to create table of Male/Female Customers, same for age !!!!#
        print("TBC: need some SQL")
        return ["need some sql"]