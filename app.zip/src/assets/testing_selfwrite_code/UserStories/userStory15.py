# -*- coding: utf-8 -*-
"""
Created on Tue Sep  6 21:24:58 2016

@author: user
"""

def userStory15(GUI):
    """(Boolean for GUI, ) """
        