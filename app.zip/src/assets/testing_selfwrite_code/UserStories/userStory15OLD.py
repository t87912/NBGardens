# -*- coding: utf-8 -*-
"""
Created on Tue Sep  6 21:24:58 2016

@author: user
"""

def userStory15(MongoQueries, GUI):
        """ useCase15 """
        #!!!! againn need SQL for date !!!!#
        print("TBC: need some SQL")